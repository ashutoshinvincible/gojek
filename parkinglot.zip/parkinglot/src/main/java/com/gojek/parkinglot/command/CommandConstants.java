package com.gojek.parkinglot.command;

public class CommandConstants {
	public static final String PARK = "park";
	public static final String CREATE_PARK_LOT = "create_parking_lot";
	public static final String STATUS = "status";
	public static final String LEAVE = "leave";
	public static final String REG_NUM_COLOR = "registration_numbers_for_cars_with_colour";
	public static final String SLOT_NUM_COLOUR = "slot_numbers_for_cars_with_colour";
	public static final String SLOT_NUM_CAR_REG = "slot_number_for_registration_number";
}
