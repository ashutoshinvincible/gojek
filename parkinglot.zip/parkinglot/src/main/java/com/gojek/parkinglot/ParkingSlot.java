package com.gojek.parkinglot;


public class ParkingSlot {
	private String vehicleRegNumber;
	private String vehicleColor;
	private String parkingSlot;

	public String getVehicleRegNumber() {
		return vehicleRegNumber;
	}

	public void setVehicleRegNumber(String vehicleRegNumber) {
		this.vehicleRegNumber = vehicleRegNumber;
	}

	public String getVehicleColor() {
		return vehicleColor;
	}

	public void setVehicleColor(String vehicleColor) {
		this.vehicleColor = vehicleColor;
	}

	public String getParkingSlot() {
		return parkingSlot;
	}

	public void setParkingSlot(String parkingSlot) {
		this.parkingSlot = parkingSlot;
	}

	public ParkingSlot(String vehicleRegNumber, String parkingSlot,String vehilceColor) {
		this.vehicleRegNumber = vehicleRegNumber;
		this.vehicleColor = vehilceColor;
		this.parkingSlot = parkingSlot;
	}
}
