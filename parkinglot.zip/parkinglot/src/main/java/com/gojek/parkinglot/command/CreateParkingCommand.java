package com.gojek.parkinglot.command;

import com.gojek.parkinglot.ParkingModel;

public class CreateParkingCommand implements Command {
    @Override
	public boolean validate(String[] args) {
		if(args.length!=2) {
			System.out.println("");
			throw new IllegalArgumentException("Wrong number of input for Create command");
		}
		return true;
	}
	@Override
	public void execute(ParkingModel pb, String[] args) {		
		pb.setMaxSlots(Integer.valueOf(args[1]));
		System.out.println("Created a parking lot with "+args[1]+" slots");
	}
}
