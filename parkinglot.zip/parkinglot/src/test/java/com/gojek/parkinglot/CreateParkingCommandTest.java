package com.gojek.parkinglot;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.gojek.parkinglot.command.CreateParkingCommand;



public class CreateParkingCommandTest {
	private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();

	@Before
	public void setUpStreams() {
	    System.setOut(new PrintStream(outContent));
	}

	@After
	public void cleanUpStreams() {
	    System.setOut(null);
	}
	@Test
    public void validateInput() throws Exception {
		CreateParkingCommand l = new CreateParkingCommand();
        assertTrue(l.validate(new String[]{"create_parking_lot","6"}));        
        Exception ex = null;
        try {
           l.validate(new String[]{"create_parking_lot"});
        } catch(Exception e) {
        	ex= e;
        }
        assertNotNull(ex);
    }
	
	@Test
    public void execute() throws Exception {
		CreateParkingCommand cpd = new CreateParkingCommand();
		ParkingModel pb =  new ParkingModel();
		cpd.execute(pb, new String[]{"create_parking_lot","3"});        
        assertEquals("Created a parking lot with 3 slots\n",outContent.toString());
    }
}
