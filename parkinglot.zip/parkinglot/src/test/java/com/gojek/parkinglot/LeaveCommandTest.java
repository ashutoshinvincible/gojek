package com.gojek.parkinglot;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.gojek.parkinglot.command.LeaveCommand;

public class LeaveCommandTest {
	private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();

	@Before
	public void setUpStreams() {
		System.setOut(new PrintStream(outContent));
	}

	@After
	public void cleanUpStreams() {
		System.setOut(null);
	}

	@Test
	public void validateInput() throws Exception {
		LeaveCommand leave = new LeaveCommand();
		assertTrue(leave.validate(new String[] { "leave", "4" }));
		Exception ex = null;
		try {
			leave.validate(new String[] { "leave" });
		} catch (Exception e) {
			ex = e;
		}
		assertNotNull(ex);
	}

	@Test
	public void execute() throws Exception {
		LeaveCommand leave = new LeaveCommand();
		ParkingModel pb = new ParkingModel();
		ParkingSlot ps = new ParkingSlot("KA-01-HH-1234", "1", "white");
		ParkingSlot ps1 = new ParkingSlot("PB-01-HH-1234", "2", "red");
		pb.getParkingSlot().add(ps);
		pb.getParkingSlot().add(ps1);
		pb.getRegParkingSlot().put(ps.getVehicleRegNumber(), ps);
		pb.getRegParkingSlot().put(ps1.getVehicleRegNumber(), ps1);
		List<ParkingSlot> newPSList = new ArrayList<ParkingSlot>();
		newPSList.add(ps);
		pb.getColorParkingSlot().put(ps.getVehicleColor(), newPSList);
		List<ParkingSlot> newPSList1 = new ArrayList<ParkingSlot>();
		newPSList1.add(ps1);
		pb.getColorParkingSlot().put(ps1.getVehicleColor(), newPSList1);
		leave.execute(pb, new String[] { "leave", "2" });
		assertEquals("Slot number 2 is free\n", outContent.toString());
	}
}
