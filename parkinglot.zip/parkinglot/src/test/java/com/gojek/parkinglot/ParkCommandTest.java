package com.gojek.parkinglot;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.gojek.parkinglot.command.ParkCommand;

public class ParkCommandTest {
	private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();

	@Before
	public void setUpStreams() {
		System.setOut(new PrintStream(outContent));
	}

	@After
	public void cleanUpStreams() {
		System.setOut(null);
	}

	@Test
	public void validateInput() throws Exception {
		ParkCommand pc = new ParkCommand();
		assertTrue(pc.validate(new String[] { "park", "KA-01-HH-1234", "White" }));
		Exception ex = null;
		try {
			pc.validate(new String[] { "park", "KA-01-HH-1234" });
		} catch (Exception e) {
			ex = e;
		}
		assertNotNull(ex);
	}

	@Test
	public void execute() throws Exception {
		ParkCommand pc = new ParkCommand();
		pc.validate(new String[] { "1", "3", "6" });
		ParkingModel pb = new ParkingModel();
		pc.execute(pb, new String[] { "park", "KA-01-HH-1234", "White" });
		assertEquals("Allocated slot number: 1\n", outContent.toString());
	}
}
