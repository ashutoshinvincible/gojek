#!/bin/bash
mvn clean install
java -jar target/parkinglot-0.0.1-SNAPSHOT.jar "../$1"