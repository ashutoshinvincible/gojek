package com.gojek.parkinglot.command;

import com.gojek.parkinglot.ParkingModel;

public interface Command {
	void execute(ParkingModel parkingModel, String [] inputCommand);
	boolean validate(String[] inputCommand);
}
