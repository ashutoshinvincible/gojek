package com.gojek.parkinglot;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;
import com.gojek.parkinglot.command.Command;
import com.gojek.parkinglot.command.CommandHelper;

public class ParkingSlotApplication {
	public static void main(String[] args) {
		ParkingModel pb = new ParkingModel();
		String[] inputArgs = null;
		if (args.length == 1) {
			try {
				File file = new File(args[0]);
				FileReader fileReader = new FileReader(file);
				BufferedReader bufferedReader = new BufferedReader(fileReader);
				String line;
				while ((line = bufferedReader.readLine()) != null) {
					inputArgs = line.split(" ");
					executeCommand(pb, inputArgs);
				}
				fileReader.close();
				bufferedReader.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		} else {
			Scanner in = new Scanner(System.in);
			while (true) {
				inputArgs = in.nextLine().split(" ");
				executeCommand(pb, inputArgs);
			}
		}
	}
	private static void executeCommand(ParkingModel pb, String[] inputArgs) {
		Command cmd = null;
		try {
			cmd = CommandHelper.findCommand(inputArgs);
		} catch (IllegalArgumentException e) {
			System.err.println(e.getMessage());
			return;
		}
		try {
			cmd.validate(inputArgs);
		} catch (Exception e) {
			System.err.println(e.getMessage());
			return;
		}
		cmd.execute(pb, inputArgs);
	}
}
