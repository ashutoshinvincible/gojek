package com.gojek.parkinglot.command;

public class CommandHelper {
		public static Command findCommand(String args[]) {
			switch (args[0]) {
			case CommandConstants.PARK:
				return new ParkCommand();
			case CommandConstants.CREATE_PARK_LOT:
				return new CreateParkingCommand();
			case CommandConstants.LEAVE:
				return new LeaveCommand();
			case CommandConstants.STATUS:
				return new StatusCommand();
			case CommandConstants.REG_NUM_COLOR:
				return new RegNumberColourCommand();
			case CommandConstants.SLOT_NUM_COLOUR:
				return new SlotNumberColourCommand();
			case CommandConstants.SLOT_NUM_CAR_REG:
				return new SlotNumberRegNumberCommand();
			default:
				throw new IllegalArgumentException("Unknown Command");
			}
		}
	}