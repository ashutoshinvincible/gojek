package com.gojek.parkinglot.command;

import java.util.ArrayList;
import java.util.List;

import com.gojek.parkinglot.ParkingModel;
import com.gojek.parkinglot.ParkingSlot;

public class ParkCommand implements Command {
    @Override
	public boolean validate(String[] args) {
		if (args.length != 3) {
			System.out.println("");
			throw new IllegalArgumentException("Wrong number of input for PARK command");
		}
		return true;
	}
	@Override
	public void execute(ParkingModel pb, String[] args) {
		// TODO Auto-generated method stub
		if (pb.getParkingSlotAssign().size() > 0) {
			String slot = pb.getParkingSlotAssign().pollFirst();
			ParkingSlot ps = new ParkingSlot(args[1], slot, args[2]);
			pb.getParkingSlot().set(Integer.valueOf(slot), ps);
			fillColourAndSlotMap(pb, ps);
			fillRegNumAndSlotMap(pb, ps);
			System.out.println("Allocated slot number: " + slot);
		} else {
			if (pb.getLastFillIndex() + 1 > pb.getMaxSlots() && pb.getMaxSlots() != 0) {
				System.out.println("Sorry, parking lot is full");
				return;
			}
			int nextIndex = pb.incrementAndGetLastFillIndex();
			ParkingSlot ps = new ParkingSlot(args[1], String.valueOf(nextIndex), args[2]);
			pb.getParkingSlot().add(ps);
			fillColourAndSlotMap(pb, ps);
			fillRegNumAndSlotMap(pb, ps);
			System.out.println("Allocated slot number: " + nextIndex);
		}
	}
	public void fillRegNumAndSlotMap(ParkingModel pb, ParkingSlot ps) {
		if (pb.getColorParkingSlot().containsKey(ps.getVehicleColor())) {
			pb.getColorParkingSlot().get(ps.getVehicleColor()).add(ps);
		} else {
			List<ParkingSlot> newPSList = new ArrayList<ParkingSlot>();
			newPSList.add(ps);
			pb.getColorParkingSlot().put(ps.getVehicleColor(), newPSList);
		}

	}
	public void fillColourAndSlotMap(ParkingModel pb, ParkingSlot ps) {
		pb.getRegParkingSlot().put(ps.getVehicleRegNumber(), ps);
	}
}
