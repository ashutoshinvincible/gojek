package com.gojek.parkinglot;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.gojek.parkinglot.command.RegNumberColourCommand;

public class RegNumberColourCommandTest {
	private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();

	@Before
	public void setUpStreams() {
	    System.setOut(new PrintStream(outContent));
	}

	@After
	public void cleanUpStreams() {
	    System.setOut(null);
	}
	@Test
    public void validateInput() throws Exception {
		RegNumberColourCommand l = new RegNumberColourCommand();
        assertTrue(l.validate(new String[]{"registration_numbers_for_cars_with_colour","red"}));        
        Exception ex = null;
        try {
           l.validate(new String[]{"registration_numbers_for_cars_with_colour"});
        } catch(Exception e) {
        	ex= e;
        }
        assertNotNull(ex);
    }
	
	@Test
    public void execute() throws Exception {
		RegNumberColourCommand reg = new RegNumberColourCommand();
		ParkingModel pb =  new ParkingModel();
		ParkingSlot ps = new ParkingSlot("KA-01-HH-1234","1","white");
		pb.getParkingSlot().add(ps);
		pb.getRegParkingSlot().put(ps.getVehicleRegNumber(),ps);
		List<ParkingSlot> newPSList = new ArrayList<ParkingSlot>();
		newPSList.add(ps);
		pb.getColorParkingSlot().put(ps.getVehicleColor(),newPSList);
		reg.execute(pb, new String[]{"registration_numbers_for_cars_with_colour","white"});
        assertEquals("KA-01-HH-1234\n",outContent.toString());
    }
}
